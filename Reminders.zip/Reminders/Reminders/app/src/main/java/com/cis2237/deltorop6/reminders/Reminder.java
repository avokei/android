package com.cis2237.deltorop6.reminders;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

public class Reminder {

    private UUID id;
    private String title;
    private Date date;
    private boolean resolved;

    public Reminder() {
        this(UUID.randomUUID());
        id = UUID.randomUUID();
        date = new Date();
    }

    public Reminder(UUID uuid) {
        id = uuid;
        date = new Date();
    }


    public UUID getId(){
        return id;
    }

    public void setId(UUID id){
        this.id=id;
    }

    public String getTitle(){
        return title;
    }

    public void setTitle(String title){
        this.title=title;
    }

    public Date getDate(){
        return date;
    }

    public void setDate(Date date){
        this.date=date;
    }

    public boolean getResolved(){
        return resolved;
    }

    public void setResolved(boolean resolved){
        this.resolved=resolved;
    }
}
