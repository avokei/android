package com.cis2237.deltorop6.reminders;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;

import java.util.List;
import java.util.UUID;


public class ReminderPagerActivity extends AppCompatActivity {

    private ViewPager viewPager;
    private List<Reminder> reminders;
    //private ReminderGenerator reminderGenerator = ReminderGenerator.get(getApplicationContext());
    public static final String EXTRA_REMINDER_ID = "com.cis2237.deltorop6.reminders.reminder_id";

    public static Intent newIntent(Context packageContext, UUID reminderId){
        Intent intent = new Intent(packageContext, ReminderPagerActivity.class);
        intent.putExtra(EXTRA_REMINDER_ID, reminderId);
        return intent;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reminder_pager);

        viewPager = (ViewPager)findViewById(R.id.reminder_view_pager);


        reminders = ReminderGenerator.get(this).getReminders();

        FragmentManager fm = getSupportFragmentManager();

        viewPager.setAdapter(new FragmentStatePagerAdapter(fm){
            public Fragment getItem(int position) {
                Reminder reminder = reminders.get(position);

                return ReminderFragment.newInstance(reminder.getId());
            }

            @Override
            public int getCount() {
                return reminders.size();
            }
        });

        //@Override
        //protected Fragment createFragment(){
        //    UUID reminderId = (UUID)getIntent().getSerializableExtra(EXTRA_REMINDER_ID);
        //    return ReminderFragment.newInstance(reminderId);
        //}

        UUID reminderId = (UUID)getIntent().getSerializableExtra(EXTRA_REMINDER_ID);
        for(int i = 0; i < reminders.size(); i++){
            if(reminders.get(i).getId().equals(reminderId)){
                viewPager.setCurrentItem(i);
                break;
            }
        }
    }
}
