package com.cis2237.deltorop6.reminders;


import android.content.Intent;
import android.os.Bundle;

import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import static com.cis2237.deltorop6.reminders.R.id.fragment_container;
import static com.cis2237.deltorop6.reminders.R.id.parent;


public class ReminderListFragment extends Fragment {

    //RecyclerView recyclerView;
    private RecyclerView reminderRecyclerView;
    private ReminderAdapter adapter;

    public ReminderListFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_reminder_list, container, false);

        reminderRecyclerView = (RecyclerView)v.findViewById(R.id.reminder_recycler_view);

        reminderRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        updateUI();
        return v;
    }

    @Override
    public void onResume(){
        super.onResume();

        updateUI();
    }

    private void updateUI() {
        ReminderGenerator remGen = ReminderGenerator.get(getActivity());
        List<Reminder> reminders = remGen.getReminders();
        adapter = new ReminderAdapter(reminders);
        reminderRecyclerView.setAdapter(adapter);

        if(adapter == null) {
            adapter = new ReminderAdapter(reminders);
            reminderRecyclerView.setAdapter(adapter);
        }
        else
        {
            adapter.notifyDataSetChanged();  //asks RecyclerView to reload all of the items that are currently visible.
        }

    }


    private class ReminderHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        Reminder reminder;
        TextView txtTitle;
        TextView txtDate;

        public ReminderHolder(View itemView) {
            super(itemView);
        }

        public ReminderHolder(LayoutInflater inflater, ViewGroup container){
            super(inflater.inflate(R.layout.list_item_reminder, container, false));

            txtTitle = (TextView)itemView.findViewById(R.id.reminderTitle);
            txtDate = (TextView)itemView.findViewById(R.id.reminderDate);

            itemView.setOnClickListener(this);
        }


        @Override
        public void onClick(View view) {
            Intent intent = ReminderPagerActivity.newIntent(getActivity(), reminder.getId());
            startActivity(intent);
        }

        public void Bind(Reminder remind){
            reminder=remind;

            txtTitle.setText(reminder.getTitle());
            txtDate.setText(reminder.getDate().toString());
        }
    }

    private class ReminderAdapter extends RecyclerView.Adapter<ReminderHolder> {
        private List<Reminder> reminders;

        public ReminderAdapter(List<Reminder> reminderList){
            reminders=reminderList;
        }

        @Override
        public ReminderHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());
            return new ReminderHolder(layoutInflater, parent);

        }

        @Override
        public void onBindViewHolder(ReminderHolder holder, int position) {
            Reminder reminder = reminders.get(position);
            holder.Bind(reminder);

        }

        @Override
        public int getItemCount() {
            return reminders.size();
        }
    }



}
