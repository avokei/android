package com.cis2237.deltorop6.reminders;


import android.os.Bundle;
import android.support.v4.app.Fragment;


public class ReminderListActivity extends SingleFragmentActivity {



    @Override
    protected Fragment createFragment() {
        return new ReminderListFragment();
    }

}
