package com.cis2237.deltorop6.reminders;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import database.ReminderCursorWrapper;
import database.ReminderDbSchema;
import database.ReminderBaseHelper;

import database.ReminderBaseHelper;
import database.ReminderDbSchema;


public class ReminderGenerator {

    List<Reminder> reminders;
    private static Reminder reminder;
    private Context context;
    private SQLiteDatabase database;

    private static ReminderGenerator ourInstance;

    public ReminderGenerator(Context context) {

        Context myContext = context.getApplicationContext();
        database = new ReminderBaseHelper(myContext).getWritableDatabase();

        /*for(int x=0;x<100;x++) {
            Reminder rem = new Reminder();
            rem.setTitle("Reminder #" + (x+1));
            rem.setResolved(false);  //or whatever.
            reminders.add(rem);
        }*/
    }


    public static ReminderGenerator get(Context context) {
        if (ourInstance == null) {
            ourInstance = new ReminderGenerator(context);
        }

        return ourInstance;
    }


    public Reminder getReminder(UUID id){
        ReminderCursorWrapper cursor = queryReminders(ReminderDbSchema.ReminderTable.Cols.UUID + " = ?",
                new String[]{id.toString()}
        );


        return null;
    }
    public void addReminder(Reminder r){
        ContentValues values = getContentValues(r);

        database.insert(ReminderDbSchema.ReminderTable.NAME, null, values);
    }

    public void updateReminder(Reminder r){
        String uuidString = reminder.getId().toString();
        ContentValues values = getContentValues(reminder);
        database.update(ReminderDbSchema.ReminderTable.NAME, values, ReminderDbSchema.ReminderTable.Cols.UUID + " = ?",
                new String[] { uuidString });

    }

    private ReminderCursorWrapper queryReminders(String whereClause, String[] whereArgs)
    {



        /*Cursor cursor = database.query(
                ReminderDbSchema.ReminderTable.NAME,
                null,   //selects all columns
                whereClause,
                whereArgs,
                null,
                null,
                null
        );
        return cursor;*/
        return new ReminderCursorWrapper();
    }

    public List<Reminder> getReminders(){
        ArrayList<Reminder> reminders = new ArrayList<>();
        ReminderCursorWrapper cursor = queryReminders(null, null);

        /*try
        {
            cursor.moveToFirst();   //start at the beginning
            while(!cursor.isAfterLast())
            {
                reminders.add(cursor.getReminder());
                cursor.moveToNext();
            }
        }finally{
            cursor.close();
        }*/

        return reminders;
    }

    private static ContentValues getContentValues(Reminder reminder)
    {
        ContentValues values = new ContentValues();
        values.put(ReminderDbSchema.ReminderTable.Cols.UUID, reminder.getId().toString());
        values.put(ReminderDbSchema.ReminderTable.Cols.TITLE, reminder.getTitle());
        values.put(ReminderDbSchema.ReminderTable.Cols.DATE,     reminder.getDate().getTime());
        values.put(ReminderDbSchema.ReminderTable.Cols.RESOLVED, reminder.getResolved() ? 1 : 0);
        return values;
    }

}
