package database;


import com.cis2237.deltorop6.reminders.Reminder;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.UUID;

public class ReminderCursorWrapper {

    public ReminderCursorWrapper(){
        super();
    }

    public Reminder getReminder(){
        String uuidString = ReminderDbSchema.ReminderTable.Cols.UUID.toString();
        String titleString = ReminderDbSchema.ReminderTable.Cols.TITLE.toString();
        String dateString = ReminderDbSchema.ReminderTable.Cols.DATE.toString();
        String resolvedString = ReminderDbSchema.ReminderTable.Cols.RESOLVED.toString();

        Reminder reminder = new Reminder(UUID.fromString(uuidString));

        reminder.setTitle(titleString);
        reminder.setDate(new Date(dateString));
        reminder.setResolved(Boolean.getBoolean(resolvedString));



        return reminder;
    }
}
