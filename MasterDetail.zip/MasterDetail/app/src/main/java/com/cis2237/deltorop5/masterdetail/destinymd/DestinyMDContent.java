package com.cis2237.deltorop5.masterdetail.destinymd;

import android.media.Image;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DestinyMDContent {



    public static class DestinyMDItem {
        public final String id;
        public final String details;
        public final String website_url;


        public DestinyMDItem(String id, String details, String website_url) {
            this.id = id;
            this.details = details;
            this.website_url = website_url;
        }

        public DestinyMDItem(String id, String details) {
            this.id = id;
            this.details = details;
            this.website_url = null;
        }


        @Override
        public String toString() {
            return details;
        }
    }

    public static final List<DestinyMDItem> ITEMS = new ArrayList<DestinyMDItem>();

    public static final Map<String, DestinyMDItem> ITEM_MAP = new HashMap<String, DestinyMDItem>();

    private static final int COUNT = 25;

    static {
        addItem(new DestinyMDItem("1", "Destiny Raid Photo"));
        addItem(new DestinyMDItem("2", "Destiny Raid Information"));
        addItem(new DestinyMDItem("1", "Destiny Raid Website","https://www.bungie.net/en/Explore/Detail/Event/3660836525"));
    }

    private static void addItem(DestinyMDItem item) {
        ITEMS.add(item);
        ITEM_MAP.put(item.id, item);
    }

    private static DestinyMDItem createDestinyMDItem(int position) {
        return new DestinyMDItem(String.valueOf(position), makeDetails(position), "website name", "website url");
    }

    private static String makeDetails(int position) {
        StringBuilder builder = new StringBuilder();
        builder.append("Details about Item: ").append(position);
        for (int i = 0; i < position; i++) {
            builder.append("\nMore details information here.");
        }
        return builder.toString();
    }





    public DestinyMDContent(String id, String details)
    {

    }

}
